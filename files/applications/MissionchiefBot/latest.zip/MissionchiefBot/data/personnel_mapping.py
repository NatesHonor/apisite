personnel_map = {
    "swat personnel (in swat vehicles)": "SWAT Armoured Vehicle",
    "riot police bus": "Riot Police Bus",
    "riot police van": "Riot Police Van",
    "traffic control": ["police traffic blocker unit", "fire traffic blocker unit"],
    "ems mobile command": "EMS Mobile Command Unit",
    "em mobile command": "EMS Mobile Command Unit",
    "usar": "Fire Traffic Blocker",
}
